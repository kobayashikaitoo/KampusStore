<?php
// ============================================================
// KampusStore — Database Configuration
// ============================================================

define('DB_HOST',    'localhost');
define('DB_PORT',    '3306');
define('DB_NAME',    'kampusstore');
define('DB_USER',    'kampusstore');
define('DB_PASS',    'ks_dev_2026');
define('DB_CHARSET', 'utf8mb4');

// Auto-detect BASE_URL (works for subfolder and vhost root)
if (!defined('BASE_URL')) {
    $script_path = $_SERVER['SCRIPT_NAME'] ?? '/';
    $base_path = rtrim(str_replace('\\', '/', dirname($script_path)), '/');
    // Normalize when script is inside a known subfolder
    $base_path = preg_replace('#/(auth|admin|api)$#', '', $base_path);
    define('BASE_URL', $base_path === '' ? '/' : $base_path . '/');
}

/**
 * Mengembalikan instance PDO (singleton).
 */
function getDB(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=%s',
            DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
        );
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log('DB Connection failed: ' . $e->getMessage());
            http_response_code(503);
            die(json_encode(['error' => 'Database tidak tersedia.']));
        }
    }

    return $pdo;
}
